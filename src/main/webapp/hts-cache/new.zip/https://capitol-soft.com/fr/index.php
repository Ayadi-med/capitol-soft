<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Capitol Soft</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="../img/logo1.png" rel="icon">
  <link href="../img/logo1.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="../lib/animate/animate.min.css" rel="stylesheet">
  <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="../lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="../lib/magnific-popup/magnific-popup.css" rel="stylesheet">





<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Main Stylesheet File -->
  <link href="../css/style.css" rel="stylesheet">
   <link href="../css/cost.css" rel="stylesheet">



  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.css">


<!------ Include the above in your HEAD tag ---------->

      <script type="text/javascript">
         $('#myCarousel').carousel({
    interval: 3000,
 })
      </script>


</head>

<body>










 <link href="../css/navbar.css" rel="stylesheet">

<style type="text/css">
	
.nav-item::after{
    content:'';
    display:block;
    width:0px;
    height:4px;
    background:#f54e0c;
    transition: 0.2s;
    margin-top:-2px;
}

.nav-item:hover::after{width:100%;}


.nav-link{padding:15px 5px;transition:0.2s;}

.navbar-nav .nav-link {
    
    color:#000;
    font-weight:bold;
    font-size:18px;
}

.navbar-nav .active > .nav-link{
  
    width:100%;
    height:51px;
    
  border-bottom: .25rem solid transparent;
  border-bottom-color: #f54e0c;
   
}
</style>
<header>
  <div class="fixed-top">
  <header class="topbar">
      <div class="container">
        <div class="row">
          <!-- social icon-->
          <div class="col-sm-6" >
            <div class="top-left pull-left">
            <ul class="social-network">
         <li><a class="waves-effect waves-dark" href="https://www.facebook.com/pages/category/Computer-Company/Capitol-Soft-848462501862388/" target="_blank" ><i class="fa fa-facebook"></i></a></li>
              <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-twitter" target="_blank"></i></a></li>
              <li><a class="waves-effect waves-dark" href="https://www.linkedin.com/company/capitol-software" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="waves-effect waves-dark" href="#"><i class="fa fa-instagram" target="_blank"></i></a></li>
            </ul>
          </div>
        </div>
           <div class="col-sm-6">
            <div class="top-right pull-right">
            <ul class="social-network">
              <li><a class="waves-effect waves-dark"href="../">EN</a></li>
              <li><a class="waves-effect waves-dark"  href="#">FR</a></li>
              
             
            </ul>
          </div>
        </div>

        </div>
      </div>
  </header></div></header>

  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto"><img src="../img/capitol.png"></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#intro"><img src="img/logo.png" alt="" title=""></a> -->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="nav-item"><a href="index.php#slider" class="active nav-link"><b>ACCUEIL</b></a></li>
          <li class="nav-item"><a href="index.php#about" class="nav-link"><b>A PROPOS</b></a></li>
          <li class="nav-item"><a href="index.php#services" class="nav-link"><b>SOLUTIONS WEB</b></a></li>
          <li class="nav-item"><a href="index.php#ERP" class="nav-link"><b>CAPITOL ERP</b></a></li>
          <li class="nav-item"><a href="index.php#SOFTWARE" class="nav-link"><b>LOGICIELS</b></a></li>
          <li class="nav-item"><a href="index.php#team" class="nav-link"><b>EQUIPE</b></a></li>
         <!-- <li><a href="index.php#gallery">GALLERIE</a></li>-->
         <!-- <li><a href="index.php#clients">CLIENT</a></li>-->
         <!-- <li class="menu-has-children"><a href="">Drop Down</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
              <li><a href="#">Drop Down 5</a></li>
            </ul>
          </li>-->
          <li class="nav-item"><a href="index.php#CONTACT" class="nav-link"><b>CONTACT</b></a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
 <br><br> <br><br>


 <link href="../css/slider.css" rel="stylesheet">
<header id="slider">
 <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="../img/ERP1.jpg" alt="images not found">
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line"></div>
                        <h2></h2>
                        <h1> ERP</h1>
                        <h4>Optimisez la gestion et le suivi de l'ensemble des processus opérationnels de votre entreprise efficacement !</h4>
                    </div>
                </div>
             </div>
        </div>  
        <div class="item">
            <img src="../img/web.jpg" alt="images not found">
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                        <h2></h2>
                        <h1>SOLUTIONS WEB</h1>
                        <h4>Site Web unique et personnalisé selon votre sphère d'activité. Des solutions web sur mesure adapté à vos besoins et qui garantit l'interactivité avec vos clients !</h4>
                    </div>
                </div>
             </div>
        </div>
          

        <div class="item">
            <img src="../img/aa2.jpg" alt="images not found">
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                        <h2></h2>
                        <h1>INTELLIGENCE ARTIFICIELLE</h1>
                        <h4>Simuler l’intelligence humaine:  E-learning, E-recrutement, E-health, E-sport</h4>
                    </div>
                </div>
             </div>
        </div>
         <div class="item">
            <img src="../img/wm.jpg" alt="images not found">
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                        <h2></h2>
                        <h1> MARKETING DIGITALE</h1>
                        <h4>Let your customers find you on the net! Invest and be a winner!</h4>
                    </div>
                </div>
             </div>
        </div>
        <div class="item">
            <img src="../img/seo1.jpg" alt="images not found">
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                        <h2></h2>
                        <h1>SEO</h1>
                        <h4>Bien positionner votre site web et booster votre entreprise en ligne !</h4>
                    </div>
                </div>
             </div>
        </div>               
        
    </div>
</header>

<script type="text/javascript">
  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
    nav:true,
    mouseDrag:false,
    autoplay:true,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
</script>
  <main id="main">







        <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

    <div class="section-header">
          <h3 class="section-title">CAPITOL SOFT</h3>
          <span class="section-divider"></span>
          <p class="section-description">
           Web, mobile et développement des logicielles sur mesure 
          </p>
        </div>

        <div class="row about-cols">

          <div class="col-md-4 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <!--<img src="img/about-mission.jpg" alt="" class="img-fluid">-->
                <img src="../img/mission.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="#"> Mission</a></h2>
              <p>
                Rendre vos idées et vos processus un œuvre numérique flexible
Exceller tous nos projets est notre mission!

              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.1s">
            <div class="about-col">
              <div class="img">
                <img src="../img/plan.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-list-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Plan</a></h2>
              <p>
                Capitol Soft emploi les bons processus et outils afin de mettre une stratégie claire et d’adopter une approche axée sur les objectifs.
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="../img/vision.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Vision</a></h2>
              <p>
                Une vision basée sur la créativité, l’innovation et la haute satisfaction de notre clientèle!  
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      About Us Section
    ============================-->




 <!--==========================
  Services Section
  ============================-->
  <section id="services">
    <div class="container wow fadeInUp">
        <div class="section-header">
          <h3 class="section-title">SOLUTIONS WEB</h3>
          <span class="section-divider"></span>
          <p class="section-description">
            Application mobile et solutions Web adaptées aux besoins du client
          </p>
        </div>

      <div class="row">
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-heart"></i></div>
          <h4 class="service-title"><a href="#">Identité Visuelle</a></h4>
          <p class="service-description">L’art de communiquer grâce aux visuels cohérents, attractifs et créatifs. Des solutions visuelles stratégiques qui vous distinguent !</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-globe"></i></div>
          <h4 class="service-title"><a href="#">Site Web</a></h4>
          <p class="service-description">S’adresser au large public grâce à internet : partager vos passions, faire connaître votre entreprise, vos services et produits.</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-globe"></i></div>
          <h4 class="service-title"><a href="#">E commerce</a></h4>
          <p class="service-description"> Fidéliser vos clients, développer votre chiffre d’affaires, et ouvrez-vous vers les marchés internationaux grâce à une boutique en ligne </p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-github"></i></div>
          <h4 class="service-title"><a href="#">Application Web</a></h4>
          <p class="service-description"> Utiliser votre PC, smartphone ou tablette et gérer en ligne les ressources et les procédures de votre entreprise.  </p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-thumbs-up"></i></div>
          <h4 class="service-title"><a href="#">Application Mobile</a></h4>
          <p class="service-description"> Le mobile permet de créer une proximité entre l’entreprise et ses clients. Soyez disponible de partout pour vos clients ! </p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-desktop"></i></div>
          <h4 class="service-title"><a href="#">SEO & SEA</a></h4>
          <p class="service-description"> Rendre votre site web visible grâce au référencement naturel et payant est une étape incontournable pour développer votre activité en ligne !</p>
        </div>
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-rocket"></i></div>
          <h4 class="service-title"><a href="#">Community Management</a></h4>
          <p class="service-description"> Toujours à l’écoute du web : agir et réagir, surveiller votre e-réputation, construire et consolider votre communauté sur le web et les réseaux sociaux.</p>
        </div>
        
        <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-heart"></i></div>
          <h4 class="service-title"><a href="#">Webmastering</a></h4>
          <p class="service-description"> Nous proposons un service de webmastering (mises à jour) de votre site sous forme de forfait mensuel.</p>
        </div>
         
         <div class="col-md-4 service-item">
          <div class="service-icon"><i class="fa fa-desktop"></i></div>
          <h4 class="service-title"><a href="#">Rédaction & traduction</a></h4>
          <p class="service-description">Rédaction et traduction de contenu des supports numériques: sites Web, applications, blogs, descriptions de produits, communiqués de presse !</p>
        </div>
         
      </div>
    </div>
  </section>

  <!--==========================
  Subscribe Section
  ============================-->



<script type="text/javascript">
  
   wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
</script>










    <!--==========================
      Call To Action Section
    ============================-->
    <section id="call-to-action">
      <div id="slider-animation" class="carousel slide" data-ride="carousel">
      <div class="container">
         <div class="text-box">
           

<div class="row">
          <div class="col-lg-8 text-center text-lg-left">
            <h3 class="cta-title" class="wow fadeInUp" data-wow-duration="4s">TELECHARGER NOTRE CATALOGUE GTARUIT</h3>
            <p class="cta-text" class="wow fadeInUp" data-wow-duration="2s"> Notre catalogue gratuit décrit brièvement nos produits. Pour obtenir une copie plus détaillée, veuillez nous contacter par e-mail.</p>
          </div>
          <div class="col-lg-4 cta-btn-container text-center wow slideInLeft" data-wow-duration="4s">
          <a class="cta-btn align-middle" href="#">CLIQUEZ ICI <br>POUR TELECHARGER</a>
          </div>
        </div>

    </div>

      </div>
    </section><!-- #call-to-action -->






 <!--==========================
      Product Featuress Section
    ============================-->
    <section id="ERP">
      <div class="container">

        <div class="row">

          <div class="col-lg-8 offset-lg-4">
            <div class="section-header wow fadeIn" data-wow-duration="1s">
              <h3 class="section-title">CAPITOL ERP</h3>
              <span class="section-divider"></span>
            </div>
          </div>

          <div class="col-lg-4 col-md-5 features-img">
            <img src="../img/product-features.jpg" alt="" class="wow fadeInLeft">
          </div>

          <div class="col-lg-8 col-md-7 ">

            <div class="row">

              <div class="col-lg-6 col-md-6 box wow fadeInRight" data-wow-delay="0.1s">
                <div class="icon"><i class="fa fa-th-list"></i></div>
                <h4 class="title"><a href="#">8 MODULES</a></h4>
                <p class="description">Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata noble dynala mark.</p>
              </div>

              <div class="col-lg-6 col-md-6 box wow fadeInRight">
                <div class="icon"><i class="fa fa-cogs"></i></div>
                <h4 class="title"><a href="#">PARAMETRABLE</a></h4>
                <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident clarida perendo.</p>
              </div>
              <div class="col-lg-6 col-md-6 box wow fadeInRight" data-wow-delay="0.2s">
                <div class="icon"><i class="fa fa-arrows-alt"></i></div>
                <h4 class="title"><a href="#">SERVICES APRES VENTE</a></h4>
                <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur teleca starter sinode park ledo.</p>
              </div>
              <div class="col-lg-6 col-md-6 box wow fadeInRight" data-wow-delay="0.3s">
                <div class="icon"><i class="fa fa-gift"></i></div>
                <h4 class="title"><a href="#">10 HEURES FORMATION GRATUIT</a></h4>
                <p class="description">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum dinoun trade capsule.</p>
              </div>
            </div>

          </div>

        </div>

      </div>

    </section><!-- #features -->
   
  
<!-- Team -->

    <!--==========================
      Gallery Section
    ============================-->
  <!--  <section id="gallery">
      <div class="container-fluid">
        <div class="section-header">
          <h3 class="section-title">GALLERIE</h3>
          <span class="section-divider"></span>
          <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
        </div>

        <div class="row no-gutters">

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-1.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-1.jpg" alt="">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-2.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-2.jpg" alt="">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-3.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-3.jpg" alt="">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-4.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-4.jpg" alt="">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-5.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-5.jpg" alt="">
              </a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="gallery-item wow fadeInUp">
              <a href="img/gallery/gallery-6.jpg" class="gallery-popup">
                <img src="img/gallery/gallery-6.jpg" alt="">
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>--><br><br><!-- #gallery -->



    <!--==========================
      Clients
    ============================-->
   <!-- <section id="clients">
      <div class="container">

        <div class="row wow fadeInUp">

          <div class="col-md-2">
            <img src="img/clients/client-1.png" alt="">
          </div>

          <div class="col-md-2">
            <img src="img/clients/client-2.png" alt="">
          </div>

          <div class="col-md-2">
            <img src="img/clients/client-3.png" alt="">
          </div>

          <div class="col-md-2">
            <img src="img/clients/client-4.png" alt="">
          </div>

          <div class="col-md-2">
            <img src="img/clients/client-5.png" alt="">
          </div>

          <div class="col-md-2">
            <img src="img/clients/client-6.png" alt="">
          </div>

        </div>
      </div>
    </section>--><!-- #more-features -->

<section >


 
<div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel" style="margin-top: -107px;">
  <div class="section-header" id="SOFTWARE">
    <br><br>
          <h3 class="section-title" style="color: #000;">Nos Logiciels</h3>
          <span class="section-divider"></span>
          <p class="section-description">
          </p>
        </div>
  <div class="carousel-inner" style="margin-top: -56px;">
    <div class="carousel-item active">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol RESTO </h4>
              <p>Gagnez du temps et gérez votre restaurant comme un chef : service rapide, satisfaction des clients, plus d’efficacité ...</p>
              <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/restoslide.png"  class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol MED</h4>
              <p>Gestion de cabinet adapté à l’univers du médecin généraliste et spécialiste </p>
                <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/medslide.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol TRANSPORT </h4>
              <p>Une solution globale et idéale de gestion de flotte automobile et de missions des chauffeurs.</p>
                <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/transportslide.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol GYM </h4>
              <p>Répond  à tous les besoins de gestion de votre salle de sports.</p>
                <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/gymslide.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol SCHOOL </h4>
              <p>Un progiciel qui assure la gestion réussite de tout types d'établissement éducatif.</p>
                <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/schoolslide.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Capitol ERP </h4>
              <p>Homogénéité, coordination, productivité, amélioration des processus et minimisation des couts.</p>
                <a href="#">Voir plus</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../img/products/erpslide.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Précédent</span> </a> <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Suivant</span> </a> </div>
<!--slide end--> 

</section>
   


  <!--==========================
      Our Team Section
    ============================-->
   <section id="team" class="pb-5">
    <div class="container">




        <div class="section-header">
          <h3 class="section-title"> EQUIPE</h3>
          <span class="section-divider"></span>
          <p class="section-description">
          </p>
        </div>
       
        <div class="row">
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/hajer.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Hajer Sahnoun</h3>
          <h4 class="title">Gérante</h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
        <!--<ul class="social">
          <li><a href="#" class="fa fa-facebook" aria-hidden="true"></a></li>
          <li><a href="#" class="fa fa-twitter" aria-hidden="true"></a></li>
          <li><a href="#" class="fa fa-linkedin" aria-hidden="true"></a></li>
        </ul>-->
      </div>
    </div>
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/adel.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Adel Chaari</h3>
          <h4 class="title">Fondateur</h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/faiez.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Faiez Bouaziz</h3>
          <h4 class="title">Responsable E-learning</h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>
 
  </div>
  <div class="row">
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
         <img class="img-fluid" src="../img/personnel/hajer.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Soumaya Mhadhbi</h3>
          <h4 class="title">Designer</h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/achref.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Achref Chaabouni</h3>
          <h4 class="title">Développeur Front-End</h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>
    
   
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/hajer.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Mohammed Naifar</h3>
          <h4 class="title">Développeur.NET </h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-md-4 col-lg-4">
      <div class="our-team">
        <div class="picture">
          <img class="img-fluid" src="../img/personnel/sahar.jpg">
        </div>
        <div class="team-content">
          <h3 class="name">Sahar Akari</h3>
          <h4 class="title">Rédacteur de Contenue </h4>
          <a href="#" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a>
        </div>
        <ul class="social">
          <li><a href="#" aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
          <li><a href="#"  aria-hidden="true"></a></li>
        </ul>
      </div>
    </div>

  </div>
    </div>
</section>











  <!--==========================
      CONTACT
    ============================-->





     <section id="CONTACT">
    
<div class="container-fluid">
   <div class="section-header">
          <h3 class="section-title">CONTACT</h3>
          <span class="section-divider"></span>
          <p class="section-description">
          </p>
        </div>

<hr>
 <div class="row">
  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d119723.64063253217!2d10.817649389184586!3d34.79689362408132!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa1961733a56d4e25!2sCapitol%20Soft!5e1!3m2!1sfr!2stn!4v1570179601760!5m2!1sfr!2stn" width="100%" height="550px" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

 </div>
  <div class="row text-center">
    <div class="col-4 box1 pt-4">
        <a href="#" class="aa"><i class="fa fa-phone fa-3x"></i>
        <h3 class="d-none d-lg-block d-xl-block">Téléphone</h3>
        <p class="d-none d-lg-block d-xl-block">(+216) 74 68 10 84</p></a>
      </div>
      <div class="col-4 box2 pt-4">
        <a href="" class="aa"><i class="fa fa-home fa-3x aa"></i>
        <h3 class="d-none d-lg-block d-xl-block aa">Adresse</h3>
        <p class="d-none d-lg-block d-xl-block aa">Route Aéroport km 04, Immeuble Les Parfums, Bureau A1. Sfax-Tunisie</p></a>
      </div>
      <div class="col-4 box3 pt-4">
        <a href="mailto:info@capitol-soft.com" class="aa"><i class="fa fa-envelope fa-3x"></i>
        <h3 class="d-none d-lg-block d-xl-block">E-mail</h3>
        <p class="d-none d-lg-block d-xl-block">info@capitol-soft.com</p></a>
      </div>
  </div>
</div>

  </section>


    <!--==========================
      Contact Section
    ============================-->
    <section id="contact">
      <div class="container">
        <div class="row wow fadeInUp">

          <div class="col-lg-4 col-md-4">
            <div class="contact-about">
              <h3><img src="../img/capitol.png"></h3>
              <p>Une agence web tunisienne spécialisée dans la création de site web, design graphique, référencement, e-réputation, animation de réseaux sociaux, identité visuelle, application de gestion personnalisée.</p>
              <div class="social-links" style="text-align: center;">
                <a href="https://www.facebook.com/pages/category/Computer-Company/Capitol-Soft-848462501862388/" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a>
                <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                <a href="#" target="_blank" class="linkedin"><i class="fa fa-linkedin"></i></a>
                <a href="#" class="pinterest"><i class="fa fa-instagram"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="info">
              <div>
                <i class="ion-ios-location-outline"></i>
                <p style="text-align: justify;">Route Aéroport km 04, Immeuble Les Parfums, Bureau A1. Sfax-Tunisie</p>
              </div>

              <div>
                <a href="mailto:info@capitol-soft.com">
                <i class="ion-ios-email-outline"></i>
                <p>info@capitol-soft.com</p></a>
              </div>

              <div>
                 
                <i class="ion-ios-telephone-outline"></i>
                <p>(+216) 74 68 10 84</p>
              </div>

            </div>
          </div>

          <div class="col-lg-5 col-md-8">
            <div class="form">
              <div id="sendmessage">Votre message est envoyée. Merci!</div>
              <div id="errormessage"></div>
              <form action="" method="post" role="form" class="contactForm">
                <div class="form-row">
                  <div class="form-group col-lg-6">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Votre Nom" data-rule="minlen:4" data-msg="Veuillez saisir au moins 4 caractères" />
                    <div class="validation"></div>
                  </div>
                  <div class="form-group col-lg-6">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Votre Email" data-rule="email" data-msg="Veuillez saisir un e-mail valide" />
                    <div class="validation"></div>
                  </div>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Sujet" data-rule="minlen:4" data-msg="Veuillez saisir au moins 8 caractères du sujet" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Veuillez écrire quelque chose pour nous" placeholder="Message"></textarea>
                  <div class="validation"></div>
                </div>
                <div class="text-center"><button type="submit" title="Send Message">Envoyer</button></div>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #contact -->

  </main>


 
  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 text-lg-left text-center">
          <div class="copyright">© Copyright -    © 2015-2025 Powered by 
            <a href="" ><strong style="color: #f45e23;">Capitol Soft</strong></a>
             </div>
         
      
        </div>
        <div class="col-lg-8">
          <nav class="footer-links text-lg-right text-center pt-2 pt-lg-0">
          <a href="index.php#slider" style="color: #2d53ac;">ACCUEIL</a>
          <a href="index.php#about" style="color: #2d53ac;">A PROPOS</a>
          <a href="index.php#services" style="color: #2d53ac;">SOLUTIONS WEB </a>
           <a href="index.php#ERP" style="color: #2d53ac;">CAPITOL ERP</a>
          <a href="index.php#SOFTWARE"  style="color: #2d53ac;">LOGICIELS</a>
          <a href="index.php#team" style="color: #2d53ac;">EQUIPE</a>
          <a href="index.php#CONTACT" style="color: #2d53ac;">CONTACT</a>
         <!--   <a href="index.php#gallery">GALLERIE</a>-->
         <!-- <a href="index.php#clients">CLIENT</a>-->
          </nav>
        </div>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- JavaScript Libraries -->
  <script src="../lib/jquery/jquery.min.js"></script>
  <script src="../lib/jquery/jquery-migrate.min.js"></script>
  <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../lib/easing/easing.min.js"></script>
  <script src="../lib/wow/wow.min.js"></script>
  <script src="../lib/superfish/hoverIntent.js"></script>
  <script src="../lib/superfish/superfish.min.js"></script>
  <script src="../lib/magnific-popup/magnific-popup.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="../contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="../js/main.js"></script>

</body>
</html>
